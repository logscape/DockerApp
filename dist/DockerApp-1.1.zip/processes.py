#!/usr/bin/python 
from  docker import Client 
from  app import Logger,DictionaryLogHelper
import socket
import sys
import simplejson as json  
from time import sleep 


def log_proc_stats(c,logger,interval=0,count=1):
	for count in xrange(0,count):
		for proc in c.top(name):
			proc["cname"]=name
			logger.log_dict(proc)
		sleep(interval) 


logger = Logger() 
c=Client("/var/run/docker.sock")

for container in c.list_containers():
	name=container["Names"][0][1:] 
	log_proc_stats(c,logger,interval=1,count=3) 		



sys.exit(0)


