
import socket 
import sys
import socket 
import simplejson as json 
from time import sleep 
from httplib import HTTPResponse 
from docker import Client 

client=Client("/var/run/docker.sock")
containers = [c["Names"][0][1:] for c  in client.list_containers()]
for cname in containers: 
	for proc_info in client.top(cname):
		print proc_info["pid"] 

sys.exit() 


#sock.send("GET /containers/1cfcccb4266309952beff6dd38c11fa00fe0f92aac8bca5679e2dafa4d5085f3/stats HTTP/1.1\n\n")
sock.send("GET /containers/sick_mccarthy/stats HTTP/1.1\n\n")
#reader = HtmlResponseReader(sock)
reader = RawSocketReader(sock)
print reader.read()
print reader.read()
print reader.read()
#c=Client(socket) 
#c.list_containers()

sys.exit(0) 

	
response = HTTPResponse(sock) 
response.begin() 
print response.status 
data = response.read() 
print json.loads(data).keys()
sys.exit(0) 
print "Listening ... "
reader = RawSocketReader(sock) 
reader.read()  
print reader.last_read() 
print reader.last_read() 

sock.send("GET /info HTTP/1.1\n\n")
lineReader = LineReader(sock)
for resp in lineReader.read():
	print resp
	#print json.loads(resp) 

