
from datetime import datetime 
import unittest 

class DictionaryLogHelper(object):
	@staticmethod
	def flatten(dictionary,parent=None):
		result = {} 
		if parent is not None:
			prefix=parent + "."
		else:
			prefix=""
		for k in dictionary.keys():
			key = prefix + k 
			if type(dictionary[k]) == dict:
				result.update(DictionaryLogHelper.flatten(dictionary[k],parent=key)) 
			else:
				result[key] = str(dictionary[k])
		return result 

class Logger(object):
	
	def log(self,msg):
		dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")  
		message = "%s %s" % (dt,msg) 
		#print  message.replace("network","net").replace("memory","mem").replace("stats","").replace("_.",".").replace("..",".")
		#print  message.replace("{'","{ '").replace(": '",":'") 
		print message.replace("'","\"") 

		
			 
	def log_dict(self,dictionary):
		self.log(DictionaryLogHelper.flatten(dictionary)) 
		pass 		


class TestDictionaryLogHelper(unittest.TestCase):
	test_map = {}
	def setUp(self):
		self.test_map = {"k1":"v1" , "k2":{ "2":"v2" } , "k3":{ "3": { "4": "v4" } }}  
		
	def test_flatten(self):
		result = DictionaryLogHelper.flatten({"k":"v"} )
		self.assertTrue(result.keys() == ["k"]); 

	def test_flatten_twolevels(self):
		result = DictionaryLogHelper.flatten({"parent":{"child":"v"}, "aunt":"" })
		self.assertTrue(result.keys() == ["parent.child","aunt"], "Result keys are : %s "  % result.keys()); 
	def test_flatten_threelevels(self):
		result = DictionaryLogHelper.flatten({"parent":{"father":{"son":"0"}}})
		self.assertTrue(result.keys() == ["parent.father.son"], "Result keys are : %s "  % result.keys()); 


		


if __name__ == "__main__":
	unittest.main() 
