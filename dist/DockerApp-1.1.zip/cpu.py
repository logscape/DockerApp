#!/usr/bin/python
from  docker import Client 
from  app import Logger,DictionaryLogHelper
import socket
import sys
import simplejson as json  


logger = Logger() 
c=Client("/var/run/docker.sock")

for container in c.list_containers():
	name=container["Names"][0][1:] 
	metrics=c.stats(name,count=1)[0]
	metrics["cname"]=name
	core_id=0
	
	for usage in  metrics["cpu_stats"]["cpu_usage"]["percpu_usage"]:
		logger.log_dict({"cname":name,"core":core_id,"usage":str(usage)})
		core_id=core_id+1
	metrics["cpu_stats"].pop("cpu_usage")
	cpu_stats = {"cname":name}
	cpu_stats.update(metrics["cpu_stats"])
	logger.log_dict(cpu_stats)
#.keys()

sys.exit(0)


