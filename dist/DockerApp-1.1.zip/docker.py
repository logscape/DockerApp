#!/usr/bin/python 
import sys
import socket 
import simplejson as json 
from time import sleep 
from httplib import HTTPResponse 


class RawSocketReader(object):
	BUFFER_SIZE=4096
	def __init__(self,socket):
		pass
		self.socket=socket
		self.last_response = None
		self.last_read_bytes = -1

	def read(self):
		sock=self.socket
		read_bytes=0
		response=[] 
		BUFFER_SIZE=4096
		while True:
			resp=sock.recv(BUFFER_SIZE) 
			read_bytes+=len(resp)
			response.append(resp) 
			if read_bytes < self.BUFFER_SIZE:
				break 
		self.last_read_bytes=read_bytes
		self.last_response = response 
		return response 

	def last_read_stats(self):
		return {"num_bytes":self.last_read_bytes}
	def last_read(self):
		return self.last_response 

class LineReader(RawSocketReader):
	LINE_COUNT=1
	def read(self):
		lines = [] 
		read_bytes=0 
		while True:
			print "reading" 
			resp=sock.recv(self.BUFFER_SIZE)
			read_bytes+=len(resp) 
			lines.extend(resp.split("\n"))  
			if len(lines)  <= self.LINE_COUNT or read_bytes < self.BUFFER_SIZE:
				break 
		self.last_read_bytes=read_bytes
		self.last_response = lines 
		return lines 

class HtmlResponseReader(RawSocketReader):
	def read(self):
		#RawSocketReader.read(self)
		#response = "".join(self.last_response) 
		#HTTPResponse(response)*/
		response=HTTPResponse(self.socket) 
		response.begin()
		data = response.read() 
		return json.loads(data) 		



class Client(object):
	def __init__(self,sock_addr):
		sock = socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
		#sock_addr = "/var/run/docker.sock" 
		sock.connect(sock_addr)
		self.socket=sock

	@staticmethod
	def html_message(url):
		return "%s HTTP/1.1\n\n" % url 

	@staticmethod
	def get(url):
		return "GET %s" % Client.html_message(url); 

	def top(self,name):
		command = Client.get("/containers/{0}/top".format(name))
		self.socket.send(command) 
		reader = HtmlResponseReader(self.socket) 
		data = reader.read()
		keys = data["Titles"]
		results = [] 
		for values in data["Processes"]:
			keys = [ k.lower() for k in keys ] 
			results.append(dict(zip(keys,values)))
		return results 
		
	def list_containers(self):
		command = Client.get("/containers/json")
		self.socket.send(command)
		reader = HtmlResponseReader(self.socket) 
		return reader.read()
	def stats(self,name,interval=0,count=1):
		self.socket.send("GET /containers/{0}/stats HTTP/1.1\n\n".format(name))
		reader = RawSocketReader(self.socket) 
		result = [] 
		for count in xrange(0,count):
			stats = [ json.loads(line) for line in  [ response_line  for  response_line in  "".join(reader.read()).split("\n") if len(response_line) > 0  ] if line[0] == '{' ] 
			result.extend(stats) 
			sleep(interval) 
		return result


