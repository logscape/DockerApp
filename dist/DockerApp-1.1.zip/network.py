#!/usr/bin/python 
from  docker import Client 
from  app import Logger,DictionaryLogHelper
import socket
import sys
import simplejson as json  


logger = Logger() 
c=Client("/var/run/docker.sock")

for container in c.list_containers():
	name=container["Names"][0][1:] 
	metrics=c.stats(name,count=1)[0]
	metrics["network"]["cname"]=name 
	logger.log_dict(metrics["network"]) 
	

sys.exit(0)


