
 "python mem.py".split().execute()
