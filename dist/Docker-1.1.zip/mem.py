#!/usr/bin/python 
from  docker import Client 
from  app import Logger,DictionaryLogHelper
import socket
import sys
import simplejson as json  


logger = Logger() 
c=Client("/var/run/docker.sock")

for container in c.list_containers():
	name=container["Names"][0][1:] 
	metrics=c.stats(name,count=1)[0]
	metrics["cname"]=name 
	temp = {"cname":name}
	temp.update(metrics["memory_stats"]["stats"])
	logger.log_dict(temp) 
	metrics["memory_stats"].pop("stats")
	metrics["memory_stats"]["cname"] = name 
	logger.log_dict(metrics["memory_stats"]) 
	

sys.exit(0)


