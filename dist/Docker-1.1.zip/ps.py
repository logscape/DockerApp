#!/usr/bin/python

import re
import sys 
from subprocess import call,Popen,PIPE
from docker import Client 
from app import Logger


class Processes(object):
	
	def __init__(self,pids):
		self._pids = pids 
		self._metrics = {} 

	def get(self,pid):
		return self._metrics[str(pid)] 

	def ps(self):
		pids = self._pids 
		cmd="ps -wweo uname,pid,pcpu,pmem,rsz,cmd "
		proc = Popen(cmd.split(),stdout=PIPE)
		keys="pcpu,pmem,cmd,cgroup".rsplit(',')
		delim=re.compile('\s+') 
		keys = ['user', 'pid', 'pcpu', 'pmem', 'rsz','cmd','args']
		for line in proc.stdout:
			line=line.strip() 
			values=delim.split(line,6)
			entry=dict(zip(keys,values))
			pid = str(entry["pid"])
			self._metrics[pid]=entry


client=Client("/var/run/docker.sock")
logger = Logger() 

containers = [c["Names"][0][1:] for c  in client.list_containers()]
for name in containers: 
	pids=[proc_info["pid"] for proc_info in client.top(name)]
	processes = Processes(pids)
	processes.ps()
	for pid in pids:
		container_proc_info={"cname":name}
		pid_info=processes.get(pid)
		container_proc_info.update(pid_info)
		logger.log(container_proc_info) 
			
sys.exit() 

