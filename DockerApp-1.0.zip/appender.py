#!/usr/bin/python

import subprocess

command="./cluster-stats 1 172.17.0.2".split(" ")
print command 
process=subprocess.Popen(command,stdout=subprocess.PIPE)
for line in process.stdout.readline():
	print line 
