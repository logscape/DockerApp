#!/usr/bin/python

import sys;
import os;
from datetime import datetime
import fileinput 
from socket import gethostname 
if len(sys.argv) < 2:
	print " usage: %s OUTFILE  " %(sys.argv[0]) 
	sys.exit()

outfile=sys.argv[1]

if outfile=="-":
	f=sys.stdout 
else:
	f=open(outfile,'a')
host=gethostname()
#for line in sys.stdin.readline():
for line in sys.stdin:
	#line=sys.stdin.readline()
	if not line:
		break
	f.write("%s\t%s\t%s" % (datetime.now(),host,line.rstrip()) )
	f.write("\n") 

f.close() 
