#!/usr/bin/python

import sys;
import os;
from datetime import datetime
import fileinput 
from socket import gethostname 

extra=sys.argv[1] 
f=sys.stdout 
host=gethostname()
line = sys.stdin.readline() 
while True:
	print line 
	line = sys.stdin.readline() 
	line=line.replace("*","") 
	line = "%s\t%s\t%s\t%s" % (datetime.now(),host,extra, line.rstrip()) 
	print line 
#for line in sys.stdin:
#	if not line:
#		break
#	f.write("%s\t%s\t%s\t%s" % (datetime.now(),host,extra,line.rstrip()) )
#	f.write("\n") 
#
#f.close() 
