assert "612-###-####" == "612-555-1212".replaceAll(/(\d{3})-(\d{3})-(\d{4})/) { fullMatch, areaCode, exchange, stationNumber ->
    assert fullMatch == "612-555-1212" 
    assert areaCode == "612"
    assert exchange == "555"
    assert stationNumber == "1212"
    return "$areaCode-###-####"
}

def line=" , name:bob  , lname:stewart  , fname:terrence:malick " 
println line
def a= line.replaceAll(/\, (\w+)(\:)/){ all,key,delim -> 
	", " + key + "="   
}
print a
