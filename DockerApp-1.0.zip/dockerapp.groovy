
public class Containers {

	public static def get_containers(){ 

		def process = "docker ps --no-trunc :".execute() 
		def lines=process.text.split("\n")

		def headers=lines[0].split(/\s{3,}/) 
		def data=lines[1..-1] 
		def containers  = [] 
		data.each {  line -> 
			def row=line.split(/\s{3,}/) 
			def map = [:] 
			def pairs = [headers,row].transpose() 
			pairs.each { k,v -> map[k] = v }
			containers.add(map) 
		}


		return containers
	}

}


class Test {} 
