import java.text.SimpleDateFormat 

pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)
def propertyMissing(String name) {}


class Logger{
        private static verbose=false;
        private static Logger instance = null;
        private static pout;
        private static perr;
        private Logger(){}

        def setVerboseTrue(){
                verbose=true;
        }

        def getInstance(){
                if(instance==null){
                        instance = new Logger();
                }
                return instance;
        }
        def setOutStream(def out){
                pout=out
        }
        def setErrStream(def err){
                perr=err
        }
        def log( line ){
                def dt = new Date()
                SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss zzz");
                //def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
                def timestamp=dateFormatter.format(dt)
                pout <<  "" + timestamp + "\t" + line  + "\n"
        }

        def error( line ,exception=null) {
                def dt = new Date()
                def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt)
                perr <<  "" + timestamp + "\t" + line  + "\n"
        }

        def exception(line,exception=null){
                this.error("Exception: ["+line+"]")

                if(exception!=null){
                        exception.printStackTrace(perr)
                }
        }
        def verbose(line){
                if(verbose){
                        error(line);
                }
        }
}



def shellCommandIterator(cmdString){
	def cmd=[ "bash" , "-c", cmdString.stripMargin()  ]
	return cmd.execute().text.split("\n")
}



/*
CONTAINER ID        IMAGE                             COMMAND             CREATED             STATUS              PORTS               NAMES
d8a7feb0bf9c        gomoz/test:latest                 bash                17 hours ago        Up 17 hours         11000/tcp           desperate_feynman    
d37f4f5b148b        logscape/mongodb-cluster:latest   bash                17 hours ago        Up 17 hours         27017/tcp           desperate_ptolemy0   
6e804910a6e6        logscape/mongodb-cluster:latest   bash                45 hours ago        Up 45 hours         27017/tcp           trusting_thompson    
b1c07fd75eca        logscape/mongodb-cluster:latest   bash                45 hours ago        Up 45 hours         27017/tcp           agitated_franklin 
*/
def containerHashMap=[:]
shellCommandIterator("docker ps").each{ line -> 	
	toks=line.split(/\s+/)
	cID=toks[0]
	image=toks[1]
	command=toks[2]
	names=toks[-1] 
	containerHashMap[cID]=[
		"cID":cID
		,"image":image
		,"cmd":command
		,"names":names
	]
}

/*
/proc/18074/cgroup:6:4:memory:/docker/d37f4f5b148b6dbb5d36a5f9df63c78599c53f13f2da24074828dc58832c5c7b
/proc/28291/cgroup:6:4:memory:/docker/6e804910a6e63e593f4044bc570ff2c50e9922b70a26fc00fbadc9b0a5bb606c
/proc/6371/cgroup:6:4:memory:/docker/6e804910a6e63e593f4044bc570ff2c50e9922b70a26fc00fbadc9b0a5bb606c
*/

def processHashMap=[:]

shellCommandIterator("grep -Hin memory:/docker  /proc/*/cgroup").each{ line -> 
	toks=line.split(":")
	path=toks[0]	
	cgroup=toks[4]
	pid=path.split("/")[2] 
	cID=cgroup.split("/")[2][0..11]
	processHashMap.put(pid,[:]) 
	processHashMap[pid]["cID"]=cID
	if (containerHashMap.containsKey(cID)){
		processHashMap[pid]["image"]=containerHashMap[cID]["image"]
		processHashMap[pid]["names"]=containerHashMap[cID]["names"]
		processHashMap[pid]["cmd"]=containerHashMap[cID]["cmd"]
	}
} 



/*
Get resources 
ps -wweo uname,pid,psr,pcpu,cputime,pmem,rsz,vsz,tty,s,etime,comm
*/

/*
logscape 29816  11  0.0 00:00:00  0.0  1244  18168 pts/7    R       00:00	X
root     29981   4  0.0 00:00:00  0.0  3604  73444 ?        S    17:11:38	bash
root     30140  11  0.0 00:12:57  0.0     0      0 ?        S 18-18:23:00	perl 
logscape 30191  12  0.0 00:00:00  0.0  1556  73444 ?        S    17:11:38

*/
shellCommandIterator("ps -wweo uname,pid,psr,pcpu,cputime,pmem,rsz,vsz,tty,s,etime,comm").each{ line -> 
	toks=line.split(/\s+/)
	pid=toks[1] 
	
	if (processHashMap.containsKey(pid)){
		processHashMap[pid]["pcpu"]=toks[3]
		processHashMap[pid]["pmem"]=toks[5]
		processHashMap[pid]["rss"]=toks[6]
		processHashMap[pid]["comm"]=toks[-1]
	}
}

processHashMap.keySet().each{ k -> 

	line=", pid:"+k
        line=line+ " "+ processHashMap[k]
        line=line.replace("cID",", CID")
        line=line.replace("[","")
        line=line.replace("]","")

        line= line.replaceAll(/\, (\w+)(\:)/){ all,key,delim ->
                ", "  + key + "="
        }

        logger.log(line)

}
	
