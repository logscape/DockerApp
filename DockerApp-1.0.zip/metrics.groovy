import groovy.io.*;
import java.text.SimpleDateFormat


pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)


def propertyMissing(String name) {}

def get_stat_metrics(hw,f,use_file_names=false,includes=null,excludes=null ) {	
	def map=[:]
//	if ( new File(f).exists() == false ) { println f ; System.exit(0) } 
	new File(f).eachLine{ line -> 
		def k=line.split()[0]
		def v=line.split()[1]
		def fileName = f.split("/")[-1]
		if(use_file_names) { 
			map["$fileName.$k"]=v
		}else {
			map["$hw.$k"]=v
		}
	}
	return map 
}


def sysfs_stats= [ "memory":"memory.stat", "cpuacct":"cpuacct.stat","blkio":"blkio.sectors,blkio.io_service_bytes,blkio.io_serviced,blkio.io_queued" ] 
def cc = new Containers() 
def containers=Containers.get_containers() 
def metrics = [] 
for(def c:containers){
	def cid= c["CONTAINER ID"]
	sysfs_stats.each { hw,files -> 
		def map = [:] 
		files.split(",").each {  file -> 
			def sysfs="/sys/fs/cgroup/$hw/docker/$cid/$file" 
			if(sysfs.contains("blk")) {
				map << get_stat_metrics(hw,sysfs,use_file_names=true)  
			}else {
				map << get_stat_metrics(hw,sysfs)  
			}
		} 
		map["cid"]=cid 
		map["name"]=c["NAMES"]
		map["image"]=c["IMAGE"]
		metrics.add(map) 
	}
}

for(def m:metrics) { logger.logkv(m) } 

System.exit(0)


class Logger{
        private static verbose=false;
        private static Logger instance = null;
        private static pout;
        private static perr;
        private Logger(){}

        def setVerboseTrue(){
                verbose=true;
        }

        def getInstance(){
                if(instance==null){
                        instance = new Logger();
                }
                return instance;
        }
        def setOutStream(def out){
                pout=out
        }
        def setErrStream(def err){
                perr=err
        }
        def log( line ){
                def dt = new Date()
                SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss zzz");
                //def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
                def timestamp=dateFormatter.format(dt)
                pout <<  "" + timestamp + "\t" + line  + "\n"
        }

        def logkv( map ) {
                def line=""
                for(def k: map.keySet()){
                        def v = map[k]
                        line=line +  ', "' + k + '": "' + v  +'"'
                }
                log(line)
        }
        def error( line ,exception=null) {
                def dt = new Date()
                def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt)
                perr <<  "" + timestamp + "\t" + line  + "\n"
        }

        def exception(line,exception=null){
                this.error("Exception: ["+line+"]")

                if(exception!=null){
                        exception.printStackTrace(perr)
                }
        }
        def verbose(line){
                if(verbose){
                        error(line);
                }
        }
}

